(() => {
  const ASSISTANT_ID = "vici-bundle-assistant";
  const STORAGE_KEY = "viciBundleAssistantLastHandoff";
  const TOKEN_UNIVERSE_STORAGE_KEY = "viciBundleAssistantTokenUniverse";
  const DEFAULT_HANDOFF_NETWORK = "Base";
  const TOKEN_SELECT_WAIT_MS = 800;
  const TOKEN_CLICK_RETRY_MS = 220;
  const NETWORK_SWITCH_WAIT_MS = 1200;
  const MAX_LOG_LINES = 7;
  const MARKET_REQUEST_MESSAGE = "VICI_MARKET_REQUEST";
  const MARKET_RESPONSE_MESSAGE = "VICI_MARKET_RESPONSE";
  const MARKET_FETCH_MESSAGE = "VICI_FETCH_MARKET";
  const NETWORK_SCAN_TARGETS = [
    { name: "Polygon", aliases: ["POLYGON", "MATIC"], menuIndex: 0 },
    { name: "Base", aliases: ["BASE", "COINBASE"], menuIndex: 1 },
    { name: "Arbitrum", aliases: ["ARBITRUM", "ARB"], menuIndex: 2 },
    { name: "Optimism", aliases: ["OPTIMISM", "OP MAINNET", "OP"], menuIndex: 3 },
  ];
  const TICKER_ALIASES = {
    WETH: ["WETH", "ETH"],
    ETH: ["ETH", "WETH"],
    WBTC: ["WBTC", "BTC"],
    BTC: ["BTC", "WBTC"],
    POL: ["POL", "MATIC", "POLYGON"],
    MATIC: ["MATIC", "POL", "POLYGON"],
    VIRTUAL: ["VIRTUAL", "VIRTUALS"],
    ALLO: ["ALLO", "ALLORA"],
    ETHFI: ["ETHFI", "ETHERFI", "ETHER.FI"],
    AERO: ["AERO", "AERODROME"],
    ARB: ["ARB", "ARBITRUM"],
    UNI: ["UNI", "UNISWAP"],
    LINK: ["LINK", "CHAINLINK"],
    AAVE: ["AAVE"],
    MORPHO: ["MORPHO"],
    ONDO: ["ONDO"],
    PENDLE: ["PENDLE"],
    COMP: ["COMP", "COMPOUND"],
    VCNT: ["VCNT", "VICI"],
    VVV: ["VVV", "VENICE"],
    SPX: ["SPX", "SPX6900"],
    CHZ: ["CHZ", "CHILIZ"],
    BIO: ["BIO"],
    VELVET: ["VELVET"],
    USDC: ["USDC"],
  };
  const BUILDER_TOKEN_UNIVERSE_MESSAGE = "VICI_TOKEN_UNIVERSE";

  const state = {
    handoff: null,
    minimized: false,
    position: null,
    dragging: false,
    log: [],
    support: null,
    tokenUniverse: null,
  };

  if (isBuilderPage()) initBuilderBridge();
  else if (isViciSwapPage()) init();

  async function initBuilderBridge() {
    const tokenUniverse = await readStoredTokenUniverse();
    if (tokenUniverse) postTokenUniverseToBuilder(tokenUniverse);
    window.addEventListener("message", handleBuilderMarketRequest);

    try {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== "local" || !changes[TOKEN_UNIVERSE_STORAGE_KEY]?.newValue) return;
        postTokenUniverseToBuilder(changes[TOKEN_UNIVERSE_STORAGE_KEY].newValue);
      });
    } catch {
      // Storage change updates are optional; the builder can still read the initial scan.
    }
  }

  async function handleBuilderMarketRequest(event) {
    if (event.source !== window || event.data?.source !== "vici-bundle-builder") return;
    if (event.data.type !== MARKET_REQUEST_MESSAGE) return;

    const requestId = event.data.requestId;
    const url = String(event.data.url || "");
    if (!isAllowedMarketUrl(url)) {
      postMarketResponse(requestId, { ok: false, error: "Unsupported market data URL." });
      return;
    }

    try {
      const response = await chrome.runtime.sendMessage({ type: MARKET_FETCH_MESSAGE, url });
      postMarketResponse(requestId, response || { ok: false, error: "No market response." });
    } catch (error) {
      postMarketResponse(requestId, { ok: false, error: error?.message || "Market bridge failed." });
    }
  }

  function postMarketResponse(requestId, response) {
    window.postMessage({
      source: ASSISTANT_ID,
      type: MARKET_RESPONSE_MESSAGE,
      requestId,
      ...response,
    }, "*");
  }

  function isAllowedMarketUrl(url) {
    try {
      const parsed = new URL(url);
      return (
        (parsed.origin === "https://api.coingecko.com" && parsed.pathname.startsWith("/api/v3/"))
        || (parsed.origin === "https://api.binance.com" && parsed.pathname.startsWith("/api/v3/"))
        || (parsed.origin === "https://api.exchange.coinbase.com" && parsed.pathname.startsWith("/products/"))
        || (parsed.origin === "https://min-api.cryptocompare.com" && parsed.pathname.startsWith("/data/"))
        || (parsed.origin === "https://api.dexscreener.com" && (
          parsed.pathname.startsWith("/latest/dex/")
          || parsed.pathname.startsWith("/token-pairs/v1/")
          || parsed.pathname.startsWith("/tokens/v1/")
        ))
        || (parsed.origin === "https://office.viciswap.io" && parsed.pathname.startsWith("/vs2/api/coins"))
      );
    } catch {
      return false;
    }
  }

  function isBuilderPage() {
    return /vici-bundle-builder\/index\.html/i.test(window.location.href)
      || (
        document.title === "Vici Bundle Builder"
        && document.querySelector("#matcher")
        && document.querySelector("#marketPulse")
      );
  }

  function isViciSwapPage() {
    return window.location.hostname === "app.viciswap.io";
  }

  function postTokenUniverseToBuilder(tokenUniverse) {
    window.postMessage({
      source: ASSISTANT_ID,
      type: BUILDER_TOKEN_UNIVERSE_MESSAGE,
      tokenUniverse,
    }, "*");
  }

  async function init() {
    state.handoff = parseHandoffFromUrl() || (await readStoredHandoff());
    state.tokenUniverse = await readStoredTokenUniverse();
    if (state.handoff) await storeHandoff(state.handoff);
    renderAssistant();
  }

  function parseHandoffFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const payload = params.get("payload");
    if (payload) {
      try {
        const parsed = JSON.parse(atob(payload));
        if (parsed?.tokens?.length) return normalizeHandoff(parsed);
      } catch {
        addLog("Could not read the encoded bundle payload from the URL.");
      }
    }

    const tokens = splitParam(params.get("tokens"));
    if (!tokens.length) return null;

    const weights = splitParam(params.get("weights")).map(Number);
    const amounts = splitParam(params.get("amounts")).map(Number);
    const quantities = splitParam(params.get("quantities")).map(Number);
    return normalizeHandoff({
      source: params.get("source") || "vici-bundle-builder",
      name: params.get("bundle") || "Vici bundle",
      network: params.get("network") || "",
      totalUsd: Number(params.get("amount")) || amounts.reduce((sum, amount) => sum + (Number(amount) || 0), 0),
      tokens: tokens.map((ticker, index) => ({
        ticker,
        weight: Number.isFinite(weights[index]) ? weights[index] : null,
        amountUsd: Number.isFinite(amounts[index]) ? amounts[index] : null,
        quantity: Number.isFinite(quantities[index]) ? quantities[index] : null,
      })),
    });
  }

  function splitParam(value) {
    return value ? value.split(",").map((item) => item.trim()).filter(Boolean) : [];
  }

  function normalizeHandoff(handoff) {
    const tokens = (handoff.tokens || [])
      .map((token) => ({
        ticker: String(token.ticker || "").trim().toUpperCase(),
        weight: finiteOrNull(token.weight),
        role: token.role || "",
        amountUsd: finiteOrNull(token.amountUsd),
        quantity: finiteOrNull(token.quantity),
        priceUsd: finiteOrNull(token.priceUsd),
        priceSource: token.priceSource || "",
        networks: Array.isArray(token.networks) ? token.networks.map(normalizeNetworkName).filter(Boolean) : [],
      }))
      .filter((token) => token.ticker);

    return {
      source: handoff.source || "vici-bundle-builder",
      name: handoff.name || "Vici bundle",
      network: normalizeNetworkName(handoff.network),
      totalUsd: finiteOrNull(handoff.totalUsd) || tokens.reduce((sum, token) => sum + (token.amountUsd || 0), 0),
      tokens,
    };
  }

  function normalizeNetworkName(network) {
    const normalized = String(network || "").trim().toLowerCase();
    const target = NETWORK_SCAN_TARGETS.find((item) => item.name.toLowerCase() === normalized);
    return target?.name || DEFAULT_HANDOFF_NETWORK;
  }

  function finiteOrNull(value) {
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  }

  async function readStoredHandoff() {
    try {
      const saved = await chrome.storage.local.get(STORAGE_KEY);
      return saved?.[STORAGE_KEY] || null;
    } catch {
      return null;
    }
  }

  async function storeHandoff(handoff) {
    try {
      await chrome.storage.local.set({ [STORAGE_KEY]: handoff });
    } catch {
      addLog("Could not save this handoff for later.");
    }
  }

  async function readStoredTokenUniverse() {
    try {
      const saved = await chrome.storage.local.get(TOKEN_UNIVERSE_STORAGE_KEY);
      return saved?.[TOKEN_UNIVERSE_STORAGE_KEY] || null;
    } catch {
      return null;
    }
  }

  async function storeTokenUniverse(tokenUniverse) {
    try {
      await chrome.storage.local.set({ [TOKEN_UNIVERSE_STORAGE_KEY]: tokenUniverse });
    } catch {
      addLog("Could not save the ViciSwap token scan.");
    }
  }

  function renderAssistant() {
    let root = document.getElementById(ASSISTANT_ID);
    if (!root) {
      root = document.createElement("div");
      root.id = ASSISTANT_ID;
      document.documentElement.append(root);
    }

    const tokenCount = state.handoff?.tokens?.length || 0;
    root.className = [
      state.minimized ? "vba-minimized" : "",
      state.dragging ? "vba-dragging" : "",
    ].filter(Boolean).join(" ");
    applyAssistantPosition(root);
    root.innerHTML = `
      <section class="vba-panel" aria-label="Vici Bundle Assistant">
        <header class="vba-header" title="Drag to move">
          <div>
            <p class="vba-eyebrow">Vici Bundle Assistant</p>
            <h2>${escapeHtml(state.handoff?.name || "No bundle detected")}</h2>
          </div>
          <button class="vba-icon-button" type="button" data-vba-minimize aria-label="${state.minimized ? "Expand" : "Minimize"} assistant">
            ${state.minimized ? "+" : "-"}
          </button>
        </header>
        <div class="vba-body">
          ${state.handoff ? renderBundleBody(tokenCount) : renderEmptyBody()}
        </div>
      </section>
    `;

    root.querySelector("[data-vba-minimize]")?.addEventListener("click", () => {
      state.minimized = !state.minimized;
      renderAssistant();
    });
    root.querySelector(".vba-header")?.addEventListener("pointerdown", startAssistantDrag);
    root.querySelector("[data-vba-check]")?.addEventListener("click", checkViciSwapSupport);
    root.querySelector("[data-vba-scan]")?.addEventListener("click", scanViciSwapTokenList);
    root.querySelector("[data-vba-fill]")?.addEventListener("click", autofillViciSwap);
    root.querySelector("[data-vba-copy]")?.addEventListener("click", copyPlan);
    root.querySelector("[data-vba-clear]")?.addEventListener("click", clearHandoff);
  }

  function applyAssistantPosition(root = document.getElementById(ASSISTANT_ID)) {
    if (!root) return;
    if (!state.position) {
      root.style.left = "";
      root.style.top = "";
      root.style.right = "";
      root.style.bottom = "";
      return;
    }

    const { left, top } = clampAssistantPosition(state.position.left, state.position.top, root);
    state.position = { left, top };
    root.style.left = `${left}px`;
    root.style.top = `${top}px`;
    root.style.right = "auto";
    root.style.bottom = "auto";
  }

  function startAssistantDrag(event) {
    if (event.target.closest("button, a, input, select, textarea")) return;
    const root = document.getElementById(ASSISTANT_ID);
    if (!root) return;

    const rect = root.getBoundingClientRect();
    const offsetX = event.clientX - rect.left;
    const offsetY = event.clientY - rect.top;
    state.dragging = true;
    root.classList.add("vba-dragging");
    event.preventDefault();

    const move = (moveEvent) => {
      state.position = clampAssistantPosition(moveEvent.clientX - offsetX, moveEvent.clientY - offsetY, root);
      applyAssistantPosition(root);
    };
    const stop = () => {
      state.dragging = false;
      root.classList.remove("vba-dragging");
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", stop);
    };

    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", stop);
  }

  function clampAssistantPosition(left, top, root = document.getElementById(ASSISTANT_ID)) {
    const rect = root?.getBoundingClientRect?.();
    const width = rect?.width || 390;
    const height = rect?.height || 120;
    const margin = 8;
    const maxLeft = Math.max(margin, window.innerWidth - width - margin);
    const maxTop = Math.max(margin, window.innerHeight - height - margin);
    return {
      left: Math.max(margin, Math.min(left, maxLeft)),
      top: Math.max(margin, Math.min(top, maxTop)),
    };
  }

  function renderBundleBody(tokenCount) {
    return `
      <div class="vba-summary">
        <div><span>Total</span><strong>${formatCurrency(state.handoff.totalUsd)}</strong></div>
        <div><span>Coins</span><strong>${tokenCount}</strong></div>
        <div><span>Network</span><strong>${escapeHtml(state.handoff.network || "Not set")}</strong></div>
      </div>
      <div class="vba-token-list">
        ${state.handoff.tokens.map(renderTokenRow).join("")}
      </div>
      ${renderSupportSummary()}
      <div class="vba-actions">
        <button class="vba-button" type="button" data-vba-scan>Scan token list</button>
        <button class="vba-button" type="button" data-vba-check>Check support</button>
        <button class="vba-button vba-button-primary" type="button" data-vba-fill>Auto-fill ViciSwap</button>
        <button class="vba-button" type="button" data-vba-copy>Copy diagnostics</button>
        <button class="vba-button" type="button" data-vba-clear>Clear</button>
      </div>
      ${renderStatus()}
    `;
  }

  function renderEmptyBody() {
    return `
      <p class="vba-empty">
        Build a bundle in Vici Bundle Builder, then open ViciSwap with the Build in ViciSwap button. The bundle handoff will appear here.
      </p>
      ${renderStatus()}
    `;
  }

  function renderTokenRow(token) {
    const receiveNetwork = state.handoff?.network || DEFAULT_HANDOFF_NETWORK;
    const otherNetworks = (token.networks || []).filter((network) => network !== receiveNetwork);
    const networkText = `Receive: ${receiveNetwork}${otherNetworks.length ? `; also listed: ${otherNetworks.join(" / ")}` : ""}`;
    return `
      <div class="vba-token-row">
        <div>
          <strong>${escapeHtml(token.ticker)}${token.role ? ` - ${escapeHtml(token.role)}` : ""}</strong>
          <span>${token.weight ?? "--"}% - ${formatCurrency(token.amountUsd || 0)}</span>
          <small>${escapeHtml(networkText)}</small>
          <small>${token.quantity ? `${formatQuantity(token.quantity)} ${escapeHtml(token.ticker)}` : "Quantity unavailable"}</small>
        </div>
        <em>${token.priceUsd ? formatCurrency(token.priceUsd) : "Price"}</em>
      </div>
    `;
  }

  function renderSupportSummary() {
    if (!state.support && !state.tokenUniverse) return "";
    const found = state.support
      ? state.support.found.map(formatSupportMatch).join(", ") || "None"
      : "Run Check support";
    const missing = state.support
      ? state.support.missing.map((item) => item.ticker).join(", ") || "None"
      : "Run Check support";
    const scannedCount = state.tokenUniverse?.tokens?.length || 0;
    const scannedNetworks = state.tokenUniverse?.networks?.length
      ? state.tokenUniverse.networks.map((item) => `${item.network}: ${item.tokens.length}`).join(" / ")
      : "";
    return `
      <div class="vba-support">
        ${scannedCount ? `<div><span>Scanned ViciSwap tokens</span><strong>${scannedCount}</strong></div>` : ""}
        ${scannedNetworks ? `<div><span>Networks scanned</span><strong>${escapeHtml(scannedNetworks)}</strong></div>` : ""}
        <div><span>Found in ViciSwap</span><strong>${escapeHtml(found)}</strong></div>
        <div><span>Missing from search</span><strong>${escapeHtml(missing)}</strong></div>
      </div>
    `;
  }

  function formatSupportMatch(item) {
    const tickerMatch = item.alias === item.ticker ? item.ticker : `${item.ticker} as ${item.alias}`;
    const networkMatch = item.networks?.length ? ` on ${item.networks.join("/")}` : "";
    return `${tickerMatch}${networkMatch}`;
  }

  function renderStatus() {
    if (!state.log.length) {
      return `
        <div class="vba-status">
          <strong>Review first.</strong>
          This assistant can prefill visible fields, but it will not click Swap, 1 Click Swap, approve allowances, or sign a transaction.
        </div>
      `;
    }
    return `
      <div class="vba-status">
        ${state.log.slice(-MAX_LOG_LINES).map((line) => `<span>${escapeHtml(line)}</span>`).join("")}
      </div>
    `;
  }

  async function autofillViciSwap() {
    if (!state.handoff?.tokens?.length) return;
    const target = targetForCurrentHandoff();
    addLog(`Setting ViciSwap to ${target.name} before selecting Receive tokens.`);
    renderAssistant();

    const switched = await switchViciSwapNetwork(target);
    if (!switched) {
      addLog(`Could not switch to ${target.name}. Autofill stopped.`);
      renderAssistant();
      return;
    }

    addLog(`Network locked to ${target.name}. Searching and selecting Receive coins.`);
    const found = [];
    const missing = [];
    for (const token of state.handoff.tokens) {
      const result = await selectAndFillToken(token, target.name);
      if (result) {
        found.push({ ticker: token.ticker, alias: result.alias, networks: [target.name] });
      } else {
        missing.push({ ticker: token.ticker });
        state.support = { found, missing, checkedAt: new Date().toISOString() };
        addLog(`Autofill stopped. Missing on ${target.name}: ${token.ticker}.`);
        clearSearchInput();
        renderAssistant();
        return;
      }
    }

    state.support = { found, missing, checkedAt: new Date().toISOString() };
    clearSearchInput();
    addLog("Done. Review every coin, route, fee, slippage, and quote before swapping.");
    renderAssistant();
  }

  async function checkViciSwapSupport() {
    if (!state.handoff?.tokens?.length) return;
    const target = targetForCurrentHandoff();
    addLog(`Checking Receive token support on ${target.name}.`);
    renderAssistant();

    const switched = await switchViciSwapNetwork(target);
    if (!switched) {
      addLog(`Could not switch to ${target.name}. Support check stopped.`);
      renderAssistant();
      return;
    }

    const found = [];
    const missing = [];
    for (const token of state.handoff.tokens) {
      const result = await findSupportedToken(token) || findTokenInScannedUniverse(token);
      if (result) {
        found.push({ ticker: token.ticker, alias: result.alias, networks: result.networks || [target.name] });
        addLog(`${token.ticker} found${result.alias !== token.ticker ? ` as ${result.alias}` : ""} on ${target.name}.`);
      } else {
        missing.push({ ticker: token.ticker });
        addLog(`${token.ticker} not found in Receive on ${target.name}.`);
      }
    }

    state.support = { found, missing, checkedAt: new Date().toISOString() };
    addLog(`Support check: ${found.length} found, ${missing.length} missing.`);
    clearSearchInput();
    renderAssistant();
  }

  async function scanViciSwapTokenList(options = {}) {
    if (!options.preserveSupport) state.support = null;
    addLog("Scanning ViciSwap receive token lists by network.");
    if (!options.skipRenderStart) renderAssistant();

    const rawNetworkResults = [];
    for (const target of NETWORK_SCAN_TARGETS) {
      const switched = await switchViciSwapNetwork(target);
      if (!switched) {
        addLog(`Could not switch to ${target.name}.`);
        continue;
      }

      const tokens = await scanCurrentNetworkTokens();
      rawNetworkResults.push({ network: target.name, tokens, signature: signatureForTokenList(tokens) });
      addLog(`${target.name}: scanned ${tokens.length} tokens.`);
    }

    const networkResults = dedupeScannedNetworkResults(rawNetworkResults);
    if (!networkResults.length) {
      addLog("No distinct network lists were trusted. The builder token map was not updated.");
      addLog("Refresh ViciSwap, make sure the network dropdown opens, then run the scan again.");
      if (!options.skipFinalRender) renderAssistant();
      return;
    }

    if (networkResults.length < NETWORK_SCAN_TARGETS.length) {
      addLog(`Trusted ${networkResults.length} distinct network list${networkResults.length === 1 ? "" : "s"} out of ${NETWORK_SCAN_TARGETS.length}.`);
    }

    const aggregateTokens = aggregateNetworkTokens(networkResults);
    state.tokenUniverse = {
      scannedAt: new Date().toISOString(),
      networks: networkResults,
      tokens: aggregateTokens,
    };
    await storeTokenUniverse(state.tokenUniverse);
    addLog(`Scanned ${state.tokenUniverse.tokens.length} unique ViciSwap tokens across ${networkResults.length} network${networkResults.length === 1 ? "" : "s"}.`);
    if (!options.skipFinalRender) renderAssistant();
  }

  async function scanCurrentNetworkTokens() {
    clearSearchInput();
    await wait(TOKEN_SELECT_WAIT_MS);

    const scroller = findTokenListScroller();
    const tokens = new Map();
    let stableRounds = 0;
    let previousSize = 0;
    setScrollerTop(scroller, 0);
    await wait(250);

    for (let index = 0; index < 90; index += 1) {
      collectVisibleTokenRows().forEach((token) => {
        const existing = tokens.get(token.ticker);
        if (!existing) {
          tokens.set(token.ticker, { ticker: token.ticker, text: token.text, address: token.address || "" });
        } else if (!existing.address && token.address) {
          existing.address = token.address;
        }
      });

      if (tokens.size === previousSize) stableRounds += 1;
      else stableRounds = 0;
      previousSize = tokens.size;

      const moved = scrollTokenList(scroller);
      await wait(180);
      if (!moved && stableRounds >= 2) break;
      if (stableRounds >= 8) break;
    }

    return [...tokens.values()].sort((a, b) => a.ticker.localeCompare(b.ticker));
  }

  function dedupeScannedNetworkResults(networkResults) {
    const groups = new Map();
    networkResults.forEach((result) => {
      if (!groups.has(result.signature)) groups.set(result.signature, []);
      groups.get(result.signature).push(result);
    });

    const deduped = [];
    groups.forEach((group) => {
      if (group.length === 1) {
        deduped.push(group[0]);
        return;
      }

      const skipped = group.map((item) => item.network).join(", ");
      addLog(`${skipped} returned identical token lists, so that ambiguous scan data was ignored.`);
    });

    return deduped.map(({ network, tokens }) => ({ network, tokens }));
  }

  function signatureForTokenList(tokens) {
    return [...new Set((tokens || []).map((token) => token.ticker).filter(Boolean))]
      .sort()
      .join("|");
  }

  function aggregateNetworkTokens(networkResults) {
    const tokens = new Map();
    networkResults.forEach((networkResult) => {
      networkResult.tokens.forEach((token) => {
        const existing = tokens.get(token.ticker) || { ticker: token.ticker, text: token.text, networks: [], addresses: {} };
        if (!existing.networks.includes(networkResult.network)) existing.networks.push(networkResult.network);
        if (!existing.text && token.text) existing.text = token.text;
        if (token.address) existing.addresses[networkResult.network] = token.address;
        tokens.set(token.ticker, existing);
      });
    });
    return [...tokens.values()].sort((a, b) => a.ticker.localeCompare(b.ticker));
  }

  async function switchViciSwapNetwork(target) {
    const dropdown = findNetworkDropdownButton();
    if (!dropdown) return false;

    clickElementAtCenter(dropdown);
    await wait(360);

    const menuItem = findNetworkMenuItem(target);
    if (!menuItem) return false;

    clickElementAtCenter(menuItem);
    addLog(`Selected ${target.name} network.`);
    await wait(NETWORK_SWITCH_WAIT_MS);
    return true;
  }

  function findNetworkDropdownButton() {
    const rows = groupIconCandidatesIntoRows(findTopIconCandidates());
    const topRow = rows.find((row) => row.items.length >= 3);
    if (topRow) {
      return topRow.items.sort((a, b) => a.rect.left - b.rect.left).at(-1)?.clickTarget || null;
    }

    return findTopIconCandidates()
      .sort((a, b) => b.rect.left - a.rect.left || a.rect.top - b.rect.top)[0]?.clickTarget || null;
  }

  function findNetworkMenuItem(target) {
    const labeled = findNetworkMenuItemByLabel(target);
    if (labeled) return labeled;

    const columns = groupIconCandidatesIntoColumns(findTopIconCandidates({ maxTop: Math.max(430, window.innerHeight * 0.58) }));
    const menuColumn = columns
      .filter((column) => column.items.length >= 4)
      .sort((a, b) => b.items.length - a.items.length || b.height - a.height)[0];
    if (!menuColumn) return null;

    return menuColumn.items.sort((a, b) => a.rect.top - b.rect.top)[target.menuIndex]?.clickTarget || null;
  }

  function findNetworkMenuItemByLabel(target) {
    const aliases = target.aliases.map((alias) => alias.toUpperCase());
    const dropdownRect = findNetworkDropdownButton()?.getBoundingClientRect?.();
    const candidates = visibleElements("button, a, [role='button'], [role='tab'], img, svg, div")
      .map((element) => {
        const clickTarget = clickTargetForNetworkIcon(element);
        const rect = iconRect(element, clickTarget);
        const label = [
          element.getAttribute("aria-label"),
          element.getAttribute("alt"),
          element.getAttribute("title"),
          element.textContent,
          clickTarget?.getAttribute?.("aria-label"),
          clickTarget?.getAttribute?.("title"),
        ].join(" ").toUpperCase();
        return { element, clickTarget, rect, label };
      })
      .filter((candidate) => candidate.clickTarget && isNetworkIconRect(candidate.rect, Math.max(430, window.innerHeight * 0.58)))
      .filter((candidate) => aliases.some((alias) => candidate.label.includes(alias)))
      .filter((candidate) => !dropdownRect || candidate.rect.top > dropdownRect.top + 12);

    return candidates.sort((a, b) => a.rect.top - b.rect.top)[0]?.clickTarget || null;
  }

  function findTopIconCandidates(options = {}) {
    const maxTop = options.maxTop || Math.max(260, window.innerHeight * 0.36);
    const candidates = visibleElements("button, a, [role='button'], [role='tab'], img, svg")
      .map((element) => {
        const clickTarget = clickTargetForNetworkIcon(element);
        const rect = iconRect(element, clickTarget);
        return { element, clickTarget, rect };
      })
      .filter((candidate) => candidate.clickTarget && isNetworkIconRect(candidate.rect, maxTop))
      .sort((a, b) => a.rect.top - b.rect.top || a.rect.left - b.rect.left);

    return uniqueIconCandidates(candidates);
  }

  function clickTargetForNetworkIcon(element) {
    return element.closest("button, a, [role='button'], [role='tab']") || pointerSizedAncestor(element) || element;
  }

  function pointerSizedAncestor(element) {
    let current = element;
    let best = null;
    for (let depth = 0; current && depth < 6; depth += 1) {
      const rect = current.getBoundingClientRect?.();
      if (rect && rect.width >= 20 && rect.height >= 20 && rect.width <= 110 && rect.height <= 110) {
        best = current;
        const cursor = window.getComputedStyle(current).cursor;
        if (cursor === "pointer") return current;
      }
      current = current.parentElement;
    }
    return best;
  }

  function iconRect(element, clickTarget) {
    const targetRect = clickTarget?.getBoundingClientRect?.();
    if (targetRect && targetRect.width <= 90 && targetRect.height <= 90) return targetRect;
    return element.getBoundingClientRect();
  }

  function isNetworkIconRect(rect, maxTop) {
    return rect.top >= 0 && rect.top <= maxTop && rect.width >= 20 && rect.height >= 20 && rect.width <= 90 && rect.height <= 90;
  }

  function uniqueIconCandidates(candidates) {
    const seen = new Set();
    return candidates.filter((candidate) => {
      const key = [
        Math.round((candidate.rect.left + candidate.rect.width / 2) / 8),
        Math.round((candidate.rect.top + candidate.rect.height / 2) / 8),
      ].join(":");
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function clickElementAtCenter(element) {
    if (!element?.getBoundingClientRect) return false;
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const target = document.elementFromPoint(x, y) || element;
    const eventInit = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };

    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((eventName) => {
      const EventConstructor = eventName.startsWith("pointer") && window.PointerEvent ? PointerEvent : MouseEvent;
      target.dispatchEvent(new EventConstructor(eventName, eventInit));
    });
    if (typeof target.click === "function") target.click();
    return true;
  }

  function groupIconCandidatesIntoRows(candidates) {
    const rows = [];
    candidates.forEach((candidate) => {
      const centerY = candidate.rect.top + candidate.rect.height / 2;
      const row = rows.find((item) => Math.abs(item.centerY - centerY) <= 22);
      if (row) {
        row.items.push(candidate);
        row.centerY = (row.centerY + centerY) / 2;
      } else {
        rows.push({ centerY, items: [candidate] });
      }
    });
    return rows.sort((a, b) => a.centerY - b.centerY);
  }

  function groupIconCandidatesIntoColumns(candidates) {
    const columns = [];
    candidates.forEach((candidate) => {
      const centerX = candidate.rect.left + candidate.rect.width / 2;
      const column = columns.find((item) => Math.abs(item.centerX - centerX) <= 24);
      if (column) {
        column.items.push(candidate);
        column.centerX = (column.centerX + centerX) / 2;
      } else {
        columns.push({ centerX, items: [candidate], height: 0 });
      }
    });
    columns.forEach((column) => {
      const tops = column.items.map((item) => item.rect.top);
      const bottoms = column.items.map((item) => item.rect.top + item.rect.height);
      column.height = Math.max(...bottoms) - Math.min(...tops);
    });
    return columns;
  }

  async function selectAndFillToken(token, networkName = networkLabelForCurrentHandoff()) {
    const ticker = token.ticker;
    const supported = await findSupportedToken(token);
    if (!supported) {
      addLog(`${ticker} was not found in Receive on ${networkName}.`);
      return null;
    }

    if (await clickTokenRow(supported.row)) {
      addLog(`Selected ${ticker}${supported.alias !== ticker ? ` via ${supported.alias}` : ""} on ${networkName}.`);
      await wait(TOKEN_SELECT_WAIT_MS);
    } else {
      addLog(`Found ${ticker} on ${networkName}, but could not click its checkbox.`);
      return null;
    }

    const amountInput = findAmountInputNearTicker(supported.alias);
    const amountValue = token.quantity || token.amountUsd;
    if (amountInput && amountValue) {
      setInputValue(amountInput, formatPlainNumber(amountValue));
      addLog(`Filled ${ticker} amount.`);
    } else {
      addLog(`Could not find a ${ticker}-specific amount field.`);
    }
    return supported;
  }

  async function findSupportedToken(token) {
    const ticker = token.ticker;
    const searchInput = findSearchInput();
    const aliases = aliasesFor(ticker);

    for (const alias of aliases) {
      if (searchInput) {
        setInputValue(searchInput, "");
        await wait(120);
        setInputValue(searchInput, alias);
        addLog(`Searched for ${ticker}${alias !== ticker ? ` as ${alias}` : ""}.`);
        await wait(TOKEN_SELECT_WAIT_MS);
      }

      const row = findTokenRow([alias]);
      if (row) return { alias, row };
    }

    return null;
  }

  function targetForCurrentHandoff() {
    const network = state.handoff?.network || DEFAULT_HANDOFF_NETWORK;
    return NETWORK_SCAN_TARGETS.find((target) => target.name === network)
      || NETWORK_SCAN_TARGETS.find((target) => target.name === DEFAULT_HANDOFF_NETWORK)
      || NETWORK_SCAN_TARGETS[0];
  }

  function networkLabelForCurrentHandoff() {
    return state.handoff?.network || DEFAULT_HANDOFF_NETWORK;
  }

  function findTokenInScannedUniverse(token) {
    if (!state.tokenUniverse?.tokens?.length) return null;
    const aliases = aliasesFor(token.ticker);
    const targetNetwork = networkLabelForCurrentHandoff();
    for (const alias of aliases) {
      const found = state.tokenUniverse.tokens.filter((item) => {
        const matchesTicker = item.ticker === alias || textMatchesTicker(item.text, alias);
        const matchesNetwork = (item.networks || []).includes(targetNetwork);
        return matchesTicker && matchesNetwork;
      });
      if (found.length) {
        const networks = [...new Set(found.flatMap((item) => item.networks || []))];
        return { alias, networks, row: null, scanned: true };
      }
    }
    return null;
  }

  function aliasesFor(ticker) {
    const normalized = String(ticker || "").trim().toUpperCase();
    return [...new Set([normalized, ...(TICKER_ALIASES[normalized] || [])])];
  }

  function findSearchInput() {
    const scopedInputs = visibleElements("input, textarea").filter(isReceiveSideElement);
    const candidates = scopedInputs.length ? scopedInputs : visibleElements("input, textarea");
    return candidates.find((element) => {
      const label = [
        element.placeholder,
        element.getAttribute("aria-label"),
        element.name,
        element.id,
      ].join(" ").toLowerCase();
      return label.includes("search") || label.includes("token") || label.includes("coin");
    });
  }

  function clearSearchInput() {
    const searchInput = findSearchInput();
    if (searchInput) setInputValue(searchInput, "");
  }

  function isReceiveSideElement(element) {
    const receiveTop = findReceiveMarkerTop();
    if (!Number.isFinite(receiveTop)) return true;
    const rect = element.getBoundingClientRect();
    return rect.top >= receiveTop - 8;
  }

  function findReceiveMarkerTop() {
    const marker = visibleElements("span, div, p, label, strong, h1, h2, h3")
      .filter((element) => {
        const text = normalizeText(element.textContent).toUpperCase();
        return text === "RECEIVE" || (text.startsWith("RECEIVE ") && text.length <= 32);
      })
      .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)[0];
    return marker ? marker.getBoundingClientRect().top : Number.NaN;
  }

  function collectVisibleTokenRows() {
    const tokens = [];
    visibleElements("input[type='checkbox'], [role='checkbox']").filter(isReceiveSideElement).forEach((checkbox) => {
      const row = findSelectableScope(checkbox);
      const text = normalizeText(row?.textContent || "");
      const ticker = parseTickerFromRowText(text);
      if (ticker) tokens.push({ ticker, text, address: extractTokenAddress(row), row, checkbox });
    });
    return tokens;
  }

  function extractTokenAddress(row) {
    if (!row) return "";
    const candidates = [row, ...row.querySelectorAll("*")];
    for (const element of candidates) {
      const direct = extractAddressFromText([
        element.textContent,
        element.getAttribute?.("href"),
        element.getAttribute?.("src"),
        element.getAttribute?.("alt"),
        element.getAttribute?.("title"),
        element.getAttribute?.("aria-label"),
      ].filter(Boolean).join(" "));
      if (direct) return direct;

      for (const attribute of [...(element.attributes || [])]) {
        const address = extractAddressFromText(attribute.value);
        if (address) return address;
      }
    }
    return "";
  }

  function extractAddressFromText(value) {
    const match = String(value || "").match(/0x[a-fA-F0-9]{40}/);
    return match ? match[0].toLowerCase() : "";
  }

  function parseTickerFromRowText(text) {
    const skip = new Set(["MAX", "PAY", "RECEIVE", "SEARCH", "GET", "QUOTES", "CLICK", "SWAP", "NEW", "HOUR", "HOURS"]);
    const matches = text.toUpperCase().match(/\b[A-Z][A-Z0-9.]{1,11}\b/g) || [];
    const candidates = matches.filter((item) => !skip.has(item) && !item.includes("HTTP"));
    return candidates.at(-1) || "";
  }

  function findTokenListScroller() {
    const candidates = [...document.querySelectorAll("body *")]
      .filter(isVisible)
      .filter((element) => element.scrollHeight > element.clientHeight + 40)
      .filter((element) => [...element.querySelectorAll("input[type='checkbox'], [role='checkbox']")].some(isReceiveSideElement))
      .sort((a, b) => {
        const aBoxes = a.querySelectorAll("input[type='checkbox'], [role='checkbox']").length;
        const bBoxes = b.querySelectorAll("input[type='checkbox'], [role='checkbox']").length;
        return bBoxes - aBoxes || b.scrollHeight - a.scrollHeight;
      });
    return candidates[0] || document.scrollingElement || document.documentElement;
  }

  function setScrollerTop(scroller, top) {
    if (scroller === document.scrollingElement || scroller === document.documentElement || scroller === document.body) {
      window.scrollTo(0, top);
    } else {
      scroller.scrollTop = top;
    }
  }

  function scrollTokenList(scroller) {
    if (scroller === document.scrollingElement || scroller === document.documentElement || scroller === document.body) {
      const before = window.scrollY;
      window.scrollBy(0, Math.max(320, window.innerHeight * 0.7));
      return window.scrollY !== before;
    }

    const before = scroller.scrollTop;
    scroller.scrollTop += Math.max(240, scroller.clientHeight * 0.75);
    return scroller.scrollTop !== before;
  }

  function findTokenRow(aliases) {
    const terms = aliases.map((alias) => alias.toUpperCase());
    const checkboxMatch = collectVisibleTokenRows().find((token) => {
      const ticker = token.ticker.toUpperCase();
      const text = normalizeText(token.text).toUpperCase();
      return terms.some((term) => ticker === term || textMatchesTicker(text, term));
    });
    if (checkboxMatch?.row) return checkboxMatch.row;

    const tokenTextNode = visibleElements("button, [role='option'], [role='button'], li, label, div, span")
      .filter((element) => !element.closest(`#${ASSISTANT_ID}`))
      .filter(isReceiveSideElement)
      .find((element) => {
        const text = normalizeText(element.textContent).toUpperCase();
        return text.length <= 120 && terms.some((term) => textMatchesTicker(text, term));
      });
    return findSelectableScope(tokenTextNode);
  }

  function textMatchesTicker(text, ticker) {
    return text === ticker || text.startsWith(`${ticker} `) || text.endsWith(` ${ticker}`) || text.includes(` ${ticker} `);
  }

  function findSelectableScope(element) {
    let scope = element;
    for (let depth = 0; scope && depth < 7; depth += 1) {
      if (findCheckboxIn(scope) || scope.matches("button, [role='button'], [role='option'], label")) return scope;
      scope = scope.parentElement;
    }
    return element || null;
  }

  async function clickTokenRow(row) {
    if (!row) return false;
    const checkbox = findCheckboxIn(row);
    if (checkbox) {
      if (isCheckboxSelected(checkbox, row)) return true;

      const label = labelForCheckbox(checkbox);
      const clickable = closestClickable(row);
      const attempts = [
        () => clickElementAtCenter(checkbox),
        () => label && clickElementAtCenter(label),
        () => clickable && clickElementAtCenter(clickable),
        () => clickElementAtRatio(row, 0.08, 0.5),
        () => clickElementAtRatio(row, 0.5, 0.5),
        () => setCheckboxChecked(checkbox, true),
      ];

      for (const attempt of attempts) {
        if (!attempt()) continue;
        await wait(TOKEN_CLICK_RETRY_MS);
        if (isCheckboxSelected(findCheckboxIn(row) || checkbox, row)) return true;
      }

      return false;
    }

    const clickable = closestClickable(row);
    if (clickable) {
      clickElementAtCenter(clickable);
      await wait(TOKEN_CLICK_RETRY_MS);
      return true;
    }
    return false;
  }

  function findCheckboxIn(scope) {
    if (!scope) return null;
    const candidates = [
      scope,
      ...scope.querySelectorAll("input[type='checkbox'], [role='checkbox']"),
    ].filter((element) => element.matches?.("input[type='checkbox'], [role='checkbox']"))
      .filter((element) => isVisible(element) || element.matches("input[type='checkbox']"));
    return candidates[0] || null;
  }

  function isCheckboxSelected(checkbox, row) {
    if (!checkbox) return false;
    if (checkbox.matches?.(":checked")) return true;
    if (checkbox.checked === true) return true;
    if (checkbox.getAttribute("aria-checked") === "true") return true;
    if (checkbox.getAttribute("data-state") === "checked") return true;
    const selectedText = [
      checkbox.className,
      checkbox.parentElement?.className,
      row?.className,
      row?.getAttribute?.("aria-selected"),
      row?.getAttribute?.("data-state"),
    ].join(" ").toLowerCase();
    return /\b(checked|selected)\b/.test(selectedText);
  }

  function labelForCheckbox(checkbox) {
    if (!checkbox) return null;
    if (checkbox.id) {
      const escapedId = cssEscape(checkbox.id);
      const label = document.querySelector(`label[for="${escapedId}"]`);
      if (label && isVisible(label)) return label;
    }
    const wrappedLabel = checkbox.closest("label");
    return wrappedLabel && isVisible(wrappedLabel) ? wrappedLabel : null;
  }

  function clickElementAtRatio(element, xRatio, yRatio) {
    if (!element?.getBoundingClientRect) return false;
    const rect = element.getBoundingClientRect();
    if (!rect.width || !rect.height) return false;
    return clickAtPoint(rect.left + rect.width * xRatio, rect.top + rect.height * yRatio);
  }

  function clickAtPoint(x, y) {
    const target = document.elementFromPoint(x, y);
    if (!target) return false;
    const eventInit = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((eventName) => {
      const EventConstructor = eventName.startsWith("pointer") && window.PointerEvent ? PointerEvent : MouseEvent;
      target.dispatchEvent(new EventConstructor(eventName, eventInit));
    });
    if (typeof target.click === "function") target.click();
    return true;
  }

  function setCheckboxChecked(checkbox, checked) {
    if (!checkbox) return false;
    if (checkbox.matches?.("input[type='checkbox']")) {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "checked")?.set
        || Object.getOwnPropertyDescriptor(checkbox.constructor.prototype, "checked")?.set;
      if (setter) setter.call(checkbox, checked);
      else checkbox.checked = checked;
      checkbox.dispatchEvent(new Event("input", { bubbles: true }));
      checkbox.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    if (checkbox.getAttribute("role") === "checkbox") {
      checkbox.setAttribute("aria-checked", checked ? "true" : "false");
      checkbox.dispatchEvent(new Event("input", { bubbles: true }));
      checkbox.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    return false;
  }

  function cssEscape(value) {
    if (window.CSS?.escape) return CSS.escape(value);
    return String(value).replace(/["\\]/g, "\\$&");
  }

  function findAmountInputNearTicker(ticker) {
    const tickerNode = visibleElements("button, [role='option'], [role='button'], li, div, span")
      .filter((element) => !element.closest(`#${ASSISTANT_ID}`))
      .filter(isReceiveSideElement)
      .find((element) => {
        const text = normalizeText(element.textContent).toUpperCase();
        return text.length <= 160 && textMatchesTicker(text, String(ticker).toUpperCase());
      });

    let scope = tickerNode;
    for (let depth = 0; scope && depth < 6; depth += 1) {
      const input = [...scope.querySelectorAll("input")]
        .filter(isVisible)
        .find(isAmountInput);
      if (input) return input;
      scope = scope.parentElement;
    }
    return null;
  }

  function isAmountInput(input) {
    const label = [
      input.placeholder,
      input.getAttribute("aria-label"),
      input.name,
      input.id,
      input.type,
    ].join(" ").toLowerCase();
    return input.type === "number" || label.includes("amount") || label.includes("receive") || label.includes("pay") || label.includes("quantity");
  }

  function closestClickable(element) {
    if (!element) return null;
    return element.closest("button, a, [role='button'], [role='option'], [role='tab']") || element;
  }

  function visibleElements(selector) {
    return [...document.querySelectorAll(selector)].filter(isVisible);
  }

  function isVisible(element) {
    if (!element || element.closest(`#${ASSISTANT_ID}`)) return false;
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function setInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(input.constructor.prototype, "value")?.set;
    if (setter) setter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function formatPlainNumber(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return "";
    return String(Number(numeric.toFixed(8)));
  }

  async function copyPlan() {
    if (!state.handoff) return;
    const lines = [
      state.handoff.name,
      `Network: ${state.handoff.network || "not set"}`,
      `Total: ${formatCurrency(state.handoff.totalUsd)}`,
      ...state.handoff.tokens.map((token) => {
        const quantity = token.quantity ? `${formatQuantity(token.quantity)} ${token.ticker}` : "quantity unavailable";
        const receiveNetwork = state.handoff?.network || DEFAULT_HANDOFF_NETWORK;
        const otherNetworks = (token.networks || []).filter((network) => network !== receiveNetwork);
        const networks = otherNetworks.length ? ` - Receive: ${receiveNetwork}; also ${otherNetworks.join("/")}` : ` - Receive: ${receiveNetwork}`;
        return `${token.ticker}: ${token.weight ?? "--"}% - ${formatCurrency(token.amountUsd || 0)} - ${quantity}${networks}`;
      }),
    ];
    if (state.support) {
      const found = state.support.found.map(formatSupportMatch).join(", ") || "None";
      const missing = state.support.missing.map((item) => item.ticker).join(", ") || "None";
      lines.push("", "Support check:", `Found: ${found}`, `Missing: ${missing}`);
    }
    if (state.tokenUniverse?.networks?.length) {
      lines.push("", "Scanned ViciSwap networks:");
      state.tokenUniverse.networks.forEach((network) => {
        lines.push(`${network.network} (${network.tokens.length}): ${network.tokens.map((token) => token.ticker).join(", ")}`);
      });
    }
    if (state.tokenUniverse?.tokens?.length) {
      lines.push(
        "",
        `Unique scanned ViciSwap tokens (${state.tokenUniverse.tokens.length}):`,
        state.tokenUniverse.tokens.map((token) => token.ticker).join(", "),
      );
    }
    if (state.log.length) {
      lines.push("", "Assistant log:", ...state.log);
    }
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      addLog("Copied diagnostics.");
    } catch {
      addLog("Copy was blocked by the browser.");
    }
    renderAssistant();
  }

  async function clearHandoff() {
    state.handoff = null;
    state.log = [];
    state.support = null;
    state.tokenUniverse = null;
    try {
      await chrome.storage.local.remove(STORAGE_KEY);
    } catch {
      // Nothing else to do.
    }
    renderAssistant();
  }

  function addLog(message) {
    state.log.push(message);
    if (state.log.length > 30) state.log = state.log.slice(-30);
  }

  function wait(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function formatCurrency(value) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(Number(value) || 0);
  }

  function formatQuantity(value) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return "--";
    const decimals = numeric >= 100 ? 2 : numeric >= 1 ? 4 : numeric >= 0.01 ? 6 : 8;
    return numeric.toLocaleString("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: decimals,
    });
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
})();
