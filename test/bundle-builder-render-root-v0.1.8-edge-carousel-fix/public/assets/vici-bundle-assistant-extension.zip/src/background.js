const MARKET_FETCH_MESSAGE = "VICI_FETCH_MARKET";
const ALLOWED_MARKET_ORIGINS = new Set([
  "https://api.coingecko.com",
  "https://api.binance.com",
  "https://api.exchange.coinbase.com",
  "https://min-api.cryptocompare.com",
  "https://api.dexscreener.com",
  "https://office.viciswap.io",
]);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== MARKET_FETCH_MESSAGE) return false;

  const url = String(message.url || "");
  if (!isAllowedMarketUrl(url)) {
    sendResponse({ ok: false, error: "Unsupported market data URL." });
    return false;
  }

  fetch(url, { cache: "no-store" })
    .then(async (response) => {
      const text = await response.text();
      let json = null;
      try {
        json = JSON.parse(text);
      } catch {
        // Non-JSON responses are reported as errors below.
      }

      sendResponse({
        ok: response.ok && json !== null,
        status: response.status,
        json,
        error: response.ok ? "" : text.slice(0, 220),
      });
    })
    .catch((error) => {
      sendResponse({ ok: false, error: error?.message || "Market data request failed." });
    });

  return true;
});

function isAllowedMarketUrl(url) {
  try {
    const parsed = new URL(url);
    if (!ALLOWED_MARKET_ORIGINS.has(parsed.origin)) return false;
    if (parsed.origin === "https://api.exchange.coinbase.com") return parsed.pathname.startsWith("/products/");
    if (parsed.origin === "https://min-api.cryptocompare.com") return parsed.pathname.startsWith("/data/");
    if (parsed.origin === "https://api.dexscreener.com") return parsed.pathname.startsWith("/latest/dex/") || parsed.pathname.startsWith("/token-pairs/v1/") || parsed.pathname.startsWith("/tokens/v1/");
    if (parsed.origin === "https://office.viciswap.io") return parsed.pathname.startsWith("/vs2/api/coins");
    return parsed.pathname.startsWith("/api/v3/");
  } catch {
    return false;
  }
}
