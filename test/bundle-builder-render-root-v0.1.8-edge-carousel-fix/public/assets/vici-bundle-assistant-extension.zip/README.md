# Vici Bundle Assistant Extension

Prototype browser extension for Vici Bundle Builder handoffs.

## What It Does

- Reads the bundle payload from a `Build in ViciSwap` URL.
- Shows a review panel on `https://app.viciswap.io/`.
- Lists each coin, percent, dollar amount, and coin quantity.
- Tries to prefill visible ViciSwap Receive token and amount fields.
- Uses ticker aliases for common ViciSwap display differences, such as `WETH -> ETH`, `WBTC -> BTC`, and `POL -> MATIC`.
- Copies diagnostics after an autofill attempt so failed ticker matches can be debugged quickly.
- Provides a `Scan token list` step that checks Polygon, Base, Arbitrum, and Optimism, then copies discovered tickers into diagnostics.
- Saves the latest scanned ViciSwap token universe in extension storage and syncs it into Vici Bundle Builder when the builder page is open. This is now a fallback to the official ViciSwap coins API.
- Preserves token contract addresses when they are visible in ViciSwap row markup, so the Builder can request chain-specific DEX market data instead of relying only on tickers.
- Bridges approved market-data requests for the Builder, including DEX Screener and CoinGecko, so the live pulse can rank same-network candidates with fresher volume/liquidity context.
- Provides a `Check support` step that switches once to the bundle network and searches the Receive side for every bundle ticker.
- If the builder handoff includes a network, auto-fill switches to that network once, prechecks every Receive token, and does not touch the network dropdown again while selecting coins.
- Leaves all quote review, swaps, approvals, and wallet signatures to the user.

## Local Install

1. Open Chrome or Edge.
2. Go to `chrome://extensions`.
3. Turn on Developer mode.
4. Choose Load unpacked.
5. Select this folder:
   `vici-bundle-assistant-extension`
6. If you are opening the builder from a local `file://` URL, enable `Allow access to file URLs` for this extension.
7. In Vici Bundle Builder, build a bundle and click `Build in ViciSwap`.

The local `manifest.json` intentionally includes `file:///*`, `localhost`, and `127.0.0.1` so the beta can be tested from local files. Those local-only permissions should not be used for a public extension build.

## Production Manifest

`manifest.production-template.json` is a template only. Before publishing or submitting for review, replace every `https://FINAL-BUILDER-DOMAIN-HERE/*` entry with the final production Bundle Builder domain. Do not ship the production template while the placeholder is still present.

## Demo Flow

1. User builds a personalized bundle.
2. Builder opens ViciSwap with a handoff payload in the URL.
3. Extension panel appears on ViciSwap and stores the handoff.
4. If ViciSwap asks the user to log in, the user logs in first.
5. User reviews bundle details.
6. Builder first attempts to use the official ViciSwap coins API for same-network Receive-token eligibility.
7. If the API is unavailable or needs verification, user clicks `Scan token list` to collect ViciSwap receive tokens across Polygon, Base, Arbitrum, and Optimism as a fallback.
8. User clicks `Check support` to confirm every bundle coin is visible on the selected ViciSwap network.
9. User clicks `Auto-fill ViciSwap`.
10. Extension switches once to the bundle's selected network, searches each ticker, immediately clicks the matching Receive-list checkbox, and fills token-specific Receive amount fields when the UI exposes them.
11. User verifies route, quote, fees, slippage, and wallet approval manually.

## Safety Boundary

This extension should not:

- Click `Swap`, `1 Click Swap`, `Get Quotes`, or approval buttons.
- Choose what the user pays with.
- Sign transactions.
- Store wallet keys.
- Bypass ViciSwap review steps.

## Product Note

The strongest production version would use an official ViciSwap bundle payload/deep-link API. This prototype uses a content script, so the auto-fill behavior may need selector updates if the ViciSwap interface changes.

The current public ViciSwap page may show a login gate before the bundle form. This prototype preserves the handoff in extension storage so the assistant can still display the plan after login.

The network selector is treated as a dropdown whose order is Polygon, Base, Arbitrum, then Optimism. The extension does not look for a separate bundle tab because ViciSwap does not expose one. If ViciSwap changes the network dropdown order, the selector code will need to be updated.

If the extension cannot detect ViciSwap's network dropdown, manually switch to that network and run `Scan token list` or `Check support` again. Diagnostics will show which networks were actually scanned.
